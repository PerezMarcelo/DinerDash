//
// Created by joshu on 11/4/2020.
//
#pragma once

#include "Entity.h"
#include "Item.h"

class Burger {
  private:
    int x, y, width, height;
    Item* topBun;
    Item* bottomBun;
    vector<Item *> ingredients;

  public:
    Burger(int, int, int, int);
    void addIngredient(Item *item);
    void render();
    void clear();
    void setY(int y) {
        this->y = y;
    }
    void undoIngredient();
    bool equals(const Burger& otherBurger) const;
    vector<Item *> getIngredients() {
      return ingredients;
    }
};
