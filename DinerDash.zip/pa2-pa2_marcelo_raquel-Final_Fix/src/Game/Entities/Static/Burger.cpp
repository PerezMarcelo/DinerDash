//
// Created by joshu on 11/4/2020.
//

#include "Burger.h"

Burger::Burger(int x, int y, int width, int height){
    this->x = x;
    this->y = y;
    this->width = width;
    this->height = height;
}

void Burger::addIngredient(Item *item) {
    ingredients.push_back(item);
}

void Burger::render(){
    int counter = 1;
    for (Item* ingredient : ingredients){
        ingredient->sprite.draw(x-5,y-(counter * 10)+55,width*0.70,height*0.70);
        counter++;
    }
}

void Burger::clear(){
    ingredients.empty();
}

bool Burger::equals(const Burger& otherBurger) const {
	if (ingredients.size() != otherBurger.ingredients.size()) {
		return false;
	}
	for (int index = 0; index < ingredients.size(); index++) {
    	if (ingredients[index] != topBun && ingredients[index] != bottomBun) {
        	if (count(otherBurger.ingredients.begin(), otherBurger.ingredients.end(), ingredients[index]) != count(ingredients.begin(), ingredients.end(), ingredients[index])) {
            	return false;
            }
        }
    }
 
    if (otherBurger.ingredients.front() != ingredients.front() || otherBurger.ingredients.back() != ingredients.back()) {
        return false;
    }
 
    return true;
}

void Burger::undoIngredient() {
    if (ingredients.size() != 0) {
        ingredients.pop_back();
    }
}