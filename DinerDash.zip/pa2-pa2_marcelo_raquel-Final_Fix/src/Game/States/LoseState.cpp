#include "State.h"
#include "LoseState.h"
LoseState::LoseState(){
    gameOver.load("images/gameLose.png");
}
void LoseState::tick(){

}
void LoseState::render(){
    gameOver.draw(0,0, ofGetWidth(), ofGetHeight());
}
void LoseState::keyPressed(int key){

}
void LoseState::mousePressed(int x, int y, int button){

}
void LoseState::reset(){
    setFinished(false);
    setNextState("");
}