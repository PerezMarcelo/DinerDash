#include "MenuState.h"

MenuState::MenuState() {
	string text = "Start";
	startButton = new Button(ofGetWidth()/2 - text.length()*8, ofGetHeight()/2 - text.length()*11, 64, 50, "Start");
}
void MenuState::tick() {
	startButton->tick();
	if(startButton->wasPressed()){
		setNextState("Game");
		setFinished(true);
	}
}
void MenuState::render() {
	ofSetBackgroundColor(230, 230, 250);
	startButton->render();
	if (startingScreenState){
		instructions();
	}
}

void MenuState::keyPressed(int key){
	if (key == ' ') {
		startingScreenState = true;
	}
}

void MenuState::mousePressed(int x, int y, int button){
	startButton->mousePressed(x, y);
}

void MenuState::reset(){
	setFinished(false);
	setNextState("");
	startButton->reset();
}

void MenuState::instructions() {
    ofSetColor(255,0,0);
    ofDrawBitmapString("Diner Dash!\n\n", ofGetWidth()/2 - 100, ofGetHeight()/2 - 50);
    ofDrawBitmapString("Instructions:\n\n", ofGetWidth()/2 - 100, ofGetHeight()/2);
    ofDrawBitmapString("	* Click 'e' to pick up ingredients.\n", ofGetWidth()/2 - 100, ofGetHeight()/2 + 20);
    ofDrawBitmapString("	* Click 's' to serve a client.", ofGetWidth()/2 - 100, ofGetHeight()/2 + 40);
}