#include "State.h"
#include "WinState.h"
WinState::WinState(){
    gameWon.load("images/gameWon.png");
}
void WinState::tick(){

}
void WinState::render(){
    gameWon.draw(0,0, ofGetWidth(), ofGetHeight());
}
void WinState::keyPressed(int key){

}
void WinState::mousePressed(int x, int y, int button){

}
void WinState::reset(){
    setFinished(false);
    setNextState("");
}