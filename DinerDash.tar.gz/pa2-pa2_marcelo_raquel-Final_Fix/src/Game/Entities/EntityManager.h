#pragma once

#include "Entity.h"
#include "Client.h"

class EntityManager {
	private:
		int leavingClients = 0;

public:
	Client* firstClient;
	void tick();
	void render();
	void addEntity(Entity *e);
	void addClient(Client *c);
	void removeLeavingClients();
	std::vector<Entity*> entities;
	int getCounterLeavingClients(){
		return leavingClients;
	}
	int setCounterLeavingClients(){
		if (leavingClients > 0) {
			leavingClients--;
		}
	}

};