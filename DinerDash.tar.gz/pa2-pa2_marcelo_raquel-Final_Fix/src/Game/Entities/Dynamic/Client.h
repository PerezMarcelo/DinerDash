#include "Entity.h"
#include "Burger.h"

class Client: public Entity{
    private:
        Burger* burger;
        int patience=2000;
        int patienceTimingColor = 0;
        int payment = this->payment;
        int price = 0;
    public:
        Client(int, int, int, int, ofImage, Burger*);
        virtual ~Client();
        void tick();
        void render();
        int serve(Burger *burger);
        Client* nextClient=nullptr;
        bool isLeaving=false;
        Burger* getBurger() {return burger; }


};