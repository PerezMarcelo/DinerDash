#include "Client.h"

Client::Client(int x, int y, int width, int height, ofImage sprite, Burger* burger): Entity(x, y, width, height, sprite){
    this->burger = burger;
}
Client::~Client(){
    delete burger;
}
void Client::render(){
    burger->render();
    if(nextClient != nullptr){
        nextClient->render();
    }
    patienceTimingColor++;
    ofSetColor(255,255-patienceTimingColor/16,255-patienceTimingColor/16);
    sprite.draw(x, y, width, height);
}

void Client::tick(){
    patience--;
    burger->setY(y);
    if(patience == 0){
        isLeaving = true;
    }
    if(nextClient != nullptr){
        nextClient->tick();
    }
}

int Client::serve(Burger* burger){
    for (Item* i : burger->getIngredients()) {
        if (i->name == "burger") {
            price += 4;
        } else if (i->name == "cheese") {
            price += 3;
        } else if (i->name == "lettuce") {
            price += 2;
        } else if (i->name == "tomato") {
            price += 2;
        } else if (i->name == "topBun") {
            price += 1;
        } else if (i->name == "bottomBun") {
            price += 1;
        }
    }
    if (this->burger->equals(*burger)) {
        isLeaving = true;
        return payment + price;
    } else {
        return 0;
    }
}
